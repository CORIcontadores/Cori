var loginForm = document.getElementById('loginForm');
var registerForm = document.getElementById('registerForm');
var loginToggle = document.getElementById('log');
var registerToggle = document.getElementById('register');
var client=document.getElementById('client');
var conta=document.getElementById('conta');
var filled=document.querySelectorAll('fill');

loginToggle.addEventListener('click', function() {
  loginForm.style.display = 'block';
  registerForm.style.display = 'none';
});

registerToggle.addEventListener('click', function() {
  loginForm.style.display = 'none';
  registerForm.style.display = 'block';
});
client.addEventListener('click', function () {
    upCert.style.display = 'none';
})
conta.addEventListener('click', function () {
    upCert.style.display = 'block';
    filled.forEach(element => {
        element.disabled = true;
      });
})
